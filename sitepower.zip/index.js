const discord = document.querySelector('#discord')
const discordTag = document.querySelector('#discordTag')

const warning = document.querySelector('#copywarn')

discord.addEventListener('click', () => {
    navigator.clipboard.writeText(`${discordTag.innerText}`)

    warning.classList.add('warn--vis')

    setTimeout(() => {
        warning.classList.remove('warn--vis')
    }, 1500)
})